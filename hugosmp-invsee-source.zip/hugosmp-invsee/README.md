# HugoSMP Auto Invsee (Fabric 1.21.11)

Client-side helper for running `/invsee <player>` when a chat line matches a configured TPA/TPAHere request. It also supports an experimental RTPQ response matcher.

## Important limitations
- The mod cannot read another player's inventory by itself. It only sends the normal `/invsee` command; the server must allow the command and the relevant player name must appear in chat.
- HugoSMP's exact chat messages are not known here. The default regexes are examples and may need editing.
- RTPQ is server-specific. The RTPQ regex only works if the response contains a username in the configured format. It cannot guess which player you teleport near.

## Build
Use Java 21 and Gradle 8.14+ (or a compatible version), then run:

```bash
gradle build
```

The jar is written to `build/libs/`.

## Install
Copy the built `hugosmp-invsee-1.0.0.jar` into `.minecraft/mods` alongside Fabric API, then start Minecraft 1.21.11 with Fabric.

## Configure
On first launch the mod creates `config/hugosmp-invsee.properties`. Edit `requestRegex1`, etc. so capture group 1 matches the player's exact username in HugoSMP's TPA messages. `commandPrefix` defaults to `invsee `.

package de.hugosmp.invsee;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.command.v2.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public final class HugoSmpInvsee implements ClientModInitializer {
    private static final Path CONFIG = Path.of("config", "hugosmp-invsee.properties");
    private static List<Pattern> requestPatterns;
    private static List<Pattern> rtpqPatterns;
    private static String commandPrefix = "invsee";
    private static boolean rtpqEnabled = true;
    private static boolean rtpqPending = false;

    @Override
    public void onInitializeClient() {
        loadConfig();
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> handleMessage(message));
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> handleMessage(message));
        ClientSendMessageEvents.COMMAND.register(command -> {
            if (command.trim().toLowerCase().matches("^rtpq(?:\\s.*)?$")) {
                rtpqPending = rtpqEnabled;
            }
        });
    }

    private static void handleMessage(Text text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) return;
        String line = text.getString().replaceAll("§[0-9A-FK-ORa-fk-or]", "").trim();

        String playerName = findName(line, requestPatterns);
        if (playerName == null && rtpqPending && rtpqEnabled) {
            playerName = findName(line, rtpqPatterns);
        }
        if (playerName == null || playerName.equalsIgnoreCase(client.player.getName().getString())) return;

        // Avoid treating command words as player names.
        String lower = playerName.toLowerCase();
        if (List.of("teleport", "anfrage", "request", "rtpq", "tpa", "tpahere", "queue").contains(lower)) return;

        client.getNetworkHandler().sendChatCommand(commandPrefix + " " + playerName);
        rtpqPending = false;
        client.player.sendMessage(Text.literal("§a[HugoSMP Auto Invsee] §f/" + commandPrefix + " " + playerName), false);
    }

    private static String findName(String line, List<Pattern> patterns) {
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(line);
            if (matcher.find() && matcher.groupCount() >= 1) {
                String candidate = matcher.group(1);
                if (candidate != null && candidate.matches("[A-Za-z0-9_]{3,16}")) return candidate;
            }
        }
        return null;
    }

    private static void loadConfig() {
        try {
            Files.createDirectories(CONFIG.getParent());
            if (!Files.exists(CONFIG)) {
                Files.writeString(CONFIG, """
# HugoSMP Auto Invsee settings
# Edit these Java-style regexes if HugoSMP uses different chat wording.
# Capture group 1 must be the player's Minecraft username.
commandPrefix=invsee
rtpqEnabled=true
requestRegex1=(?i)^([A-Za-z0-9_]{3,16}) has requested to teleport to you.*$
requestRegex2=(?i)^([A-Za-z0-9_]{3,16}) wants to teleport to you.*$
requestRegex3=(?i)^Teleport-Anfrage von ([A-Za-z0-9_]{3,16}).*$
requestRegex4=(?i)^TPA(?:Here)?-Anfrage von ([A-Za-z0-9_]{3,16}).*$
requestRegex5=(?i)^([A-Za-z0-9_]{3,16}) möchte sich zu dir teleportieren.*$
rtpqRegex1=(?i)^RTPQ.*?([A-Za-z0-9_]{3,16}).*$
rtpqRegex2=(?i)^Random teleport queue.*?([A-Za-z0-9_]{3,16}).*$
""", StandardCharsets.UTF_8);
            }
            List<String> lines = Files.readAllLines(CONFIG, StandardCharsets.UTF_8);
            java.util.Map<String, String> values = new java.util.HashMap<>();
            for (String raw : lines) {
                String s = raw.trim();
                if (s.isEmpty() || s.startsWith("#") || !s.contains("=")) continue;
                int i = s.indexOf('=');
                values.put(s.substring(0, i).trim(), s.substring(i + 1).trim());
            }
            commandPrefix = values.getOrDefault("commandPrefix", "invsee");
            rtpqEnabled = Boolean.parseBoolean(values.getOrDefault("rtpqEnabled", "true"));
            requestPatterns = compilePatterns(values, "requestRegex");
            rtpqPatterns = compilePatterns(values, "rtpqRegex");
            if (requestPatterns.isEmpty()) requestPatterns = defaultRequestPatterns();
            if (rtpqPatterns.isEmpty()) rtpqPatterns = List.of(Pattern.compile("(?i)^RTPQ.*?([A-Za-z0-9_]{3,16}).*$"));
        } catch (IOException e) {
            requestPatterns = defaultRequestPatterns();
            rtpqPatterns = List.of(Pattern.compile("(?i)^RTPQ.*?([A-Za-z0-9_]{3,16}).*$"));
        }
    }

    private static List<Pattern> compilePatterns(java.util.Map<String, String> values, String prefix) {
        java.util.ArrayList<Pattern> patterns = new java.util.ArrayList<>();
        values.entrySet().stream().filter(e -> e.getKey().startsWith(prefix)).sorted(java.util.Map.Entry.comparingByKey()).forEach(e -> {
            try { patterns.add(Pattern.compile(e.getValue())); }
            catch (PatternSyntaxException ignored) { }
        });
        return patterns;
    }

    private static List<Pattern> defaultRequestPatterns() {
        return List.of(
            Pattern.compile("(?i)^([A-Za-z0-9_]{3,16}) has requested to teleport to you.*$"),
            Pattern.compile("(?i)^([A-Za-z0-9_]{3,16}) wants to teleport to you.*$"),
            Pattern.compile("(?i)^Teleport-Anfrage von ([A-Za-z0-9_]{3,16}).*$"),
            Pattern.compile("(?i)^TPA(?:Here)?-Anfrage von ([A-Za-z0-9_]{3,16}).*$"),
            Pattern.compile("(?i)^([A-Za-z0-9_]{3,16}) möchte sich zu dir teleportieren.*$")
        );
    }
}
